﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ClaWCodingTest.HackerNews.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using WCodingTest.HackerNews.Business.Interfaces;

namespace WCodingTest.HackerNews.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly IPostService postService;
        private readonly IMemoryCache cache;

        public PostsController(IPostService postService, IMemoryCache cache)
        {
            this.postService = postService;
            this.cache = cache;
        }

        /// <summary>
        /// Returns list of top 20 posts with details.
        /// </summary>
        /// <returns>List of top twenty posts and its details.</returns>
        [HttpGet("getTopTwenty")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public ActionResult GetTopTwenty()
        {
            try
            {
                // Defining a key to cache.
                string key = "PostKey";

                List<BestPosts> listPosts;

                // Trying to get value from cache. If can't get, do another search
                if (!cache.TryGetValue(key, out listPosts))
                {
                    // Calling service to search.
                    listPosts = postService.GetTopTwenty();

                    // Setting cache parameters, time to expire is 30 minutes.
                    MemoryCacheEntryOptions cacheExpirationOptions = new MemoryCacheEntryOptions();
                    cacheExpirationOptions.AbsoluteExpiration = DateTime.Now.AddMinutes(30);
                    cacheExpirationOptions.Priority = CacheItemPriority.Normal;

                    cache.Set(key, listPosts, cacheExpirationOptions);
                }

                return Ok(listPosts);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }
        }
    }
}