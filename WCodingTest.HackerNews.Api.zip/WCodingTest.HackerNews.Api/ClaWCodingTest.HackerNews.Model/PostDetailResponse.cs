﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClaWCodingTest.HackerNews.Model
{
    public class PostDetailResponse
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("url")]
        public string Uri { get; set; }

        [JsonProperty("by")]
        public string PostedBy { get; set; }

        [JsonProperty("time")]
        public string Time { get; set; }

        [JsonProperty("score")]
        public int Score { get; set; }

        [JsonProperty("kids")]
        public string[] CommentsIds { get; set; }
    }
}
