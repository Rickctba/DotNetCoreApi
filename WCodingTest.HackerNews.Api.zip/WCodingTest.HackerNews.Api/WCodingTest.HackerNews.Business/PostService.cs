﻿using ClaWCodingTest.HackerNews.Model;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using WCodingTest.HackerNews.Business.Interfaces;

namespace WCodingTest.HackerNews.Business
{
    public class PostService : IPostService
    {
        private string _urlTopTwentyPostsIds = "https://hacker-news.firebaseio.com/v0/beststories.json";
        private string _urlPostDetails = "https://hacker-news.firebaseio.com/v0/item/";

        /// <summary>
        /// Get list of top Twenty posts.
        /// </summary>
        /// <returns>List of top Twenty posts.</returns>
        public List<BestPosts> GetTopTwenty()
        {
            List<BestPosts> bestPostsList = new List<BestPosts>();

            List<string> topTewentyIds = GetTopTwentyPostsIds();

            foreach (var id in topTewentyIds)
            {
                using (var httpClient = new HttpClient())
                {
                    string url = string.Format("{0}{1}.json", _urlPostDetails, id);

                    // Call API to get details posts.
                    HttpResponseMessage response = httpClient.GetAsync(url).Result;

                    // Verify if success.
                    if (response.IsSuccessStatusCode)
                    {
                        // Get details.
                        PostDetailResponse postDetailsResponse = JsonConvert.DeserializeObject<PostDetailResponse>(response.Content.ReadAsStringAsync().Result);

                        if (postDetailsResponse != null)
                        {
                            // Adding to list posts.
                            bestPostsList.Add(PostDetailResponseToBestPosts(postDetailsResponse));
                        }
                    }
                }
            }

            return bestPostsList;
        }

        #region Get Top 20 Posts Ids

        /// <summary>
        /// Get top 20 posts id.
        /// </summary>
        /// <returns>List of string content ids of top 20 posts.</returns>
        private List<string> GetTopTwentyPostsIds()
        {
            List<string> topTwentyPostsIdsReturn = new List<string>();

            using (var httpClient = new HttpClient())
            {
                // Call API to get Top20 posts list.
                HttpResponseMessage response = httpClient.GetAsync(_urlTopTwentyPostsIds).Result;

                // Verify if success.
                if (response.IsSuccessStatusCode)
                {
                    // Get Posts Ids.
                    string topPostsIdsResponse = response.Content.ReadAsStringAsync().Result;
                    string[] topPostsArray = new string[0];

                    if (!string.IsNullOrEmpty(topPostsIdsResponse))
                    {
                        // Change return to an array.
                        topPostsArray = topPostsIdsResponse.Replace("[", "").Replace("]", "").Split(",");

                        // Looping to get top 20 posts ids.
                        for (int i = 0; i < (topPostsArray.Length < 20 ? topPostsArray.Length : 20); i++)
                        {
                            topTwentyPostsIdsReturn.Add(topPostsArray[i]);
                        }
                    }
                }
            }

            return topTwentyPostsIdsReturn;
        }

        #endregion

        #region Auxiliar Methods

        /// <summary>
        /// Convert UnixTimeStamp into DateTime.
        /// </summary>
        /// <param name="unixTimeStamp">UnixTimeStamp</param>
        /// <returns>String formated in DateTime.</returns>
        private string UnixTimeStampToDateTime(string unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(Convert.ToDouble(unixTimeStamp)).ToLocalTime();
            return dtDateTime.ToString("yyyy-MM-ddTHH:mm:ssK");
        }

        /// <summary>
        /// Convert PostDetailResponse object into BestPosts object.
        /// </summary>
        /// <param name="postDetailsResponse">PostDetailResponse objet to be converted.</param>
        /// <returns>BestPosts object converted.</returns>
        public BestPosts PostDetailResponseToBestPosts(PostDetailResponse postDetailsResponse)
        {
            // Converting PostDetailResponse into BestPosts.
            return new BestPosts()
            {
                Title = postDetailsResponse.Title,
                Uri = postDetailsResponse.Uri,
                PostedBy = postDetailsResponse.PostedBy,
                Time = UnixTimeStampToDateTime(postDetailsResponse.Time),
                Score = postDetailsResponse.Score,
                CommentCount = postDetailsResponse.CommentsIds.Length
            };
        }

        #endregion
    }
}
