﻿using ClaWCodingTest.HackerNews.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace WCodingTest.HackerNews.Business.Interfaces
{
    public interface IPostService
    {
        List<BestPosts> GetTopTwenty();
    }
}
