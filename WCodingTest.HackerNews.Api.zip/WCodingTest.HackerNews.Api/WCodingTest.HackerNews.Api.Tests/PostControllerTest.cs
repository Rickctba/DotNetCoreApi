﻿using ClaWCodingTest.HackerNews.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using WCodingTest.HackerNews.Api.Controllers;
using WCodingTest.HackerNews.Business.Interfaces;
using Xunit;

namespace WCodingTest.HackerNews.Api.Tests
{
    public class PostControllerTest
    {
        private readonly Mock<IPostService> mockPostService;
        private readonly Mock<IMemoryCache> mockCache;
        private readonly PostsController controller;

        public PostControllerTest()
        {
            mockPostService = new Mock<IPostService>();
            mockCache = new Mock<IMemoryCache>();
            controller = new PostsController(mockPostService.Object, mockCache.Object);
        }

        [Fact]
        public void GetTopTwenty_Ok_ShouldReturn()
        {
            var posts = GetMockBestPosts();
            var response = "json string";
            string key = "PostKey";

            mockPostService.Setup(s => s.GetTopTwenty())
                .Returns(posts);

            var memoryCache = Mock.Of<IMemoryCache>();
            var cachEntry = Mock.Of<ICacheEntry>();

            var mockMemoryCache = Mock.Get(memoryCache);
            mockMemoryCache
                .Setup(m => m.CreateEntry(It.IsAny<object>()))
                .Returns(cachEntry);

            var cachedResponse = memoryCache.Set(key, response, new MemoryCacheEntryOptions());

            var retPosts = controller.GetTopTwenty();

            Assert.NotNull(retPosts);
        }

        [Fact]
        public void MemoryCache_IsNotNull_CacheResponse()
        {
            var response = "json string";
            string key = "PostKey";

            var memoryCache = Mock.Of<IMemoryCache>();
            var cachEntry = Mock.Of<ICacheEntry>();

            var mockMemoryCache = Mock.Get(memoryCache);
            mockMemoryCache
                .Setup(m => m.CreateEntry(It.IsAny<object>()))
                .Returns(cachEntry);

            var cachedResponse = memoryCache.Set<string>(key, response, new MemoryCacheEntryOptions());

            Assert.NotNull(cachedResponse);
            Assert.Equal(response, cachedResponse);
        }

        [Fact]
        public void GetTopTwenty_Nok_Exception()
        {
            var response = "json string";
            string key = "PostKey";

            var posts = GetMockBestPosts();

            var memoryCache = Mock.Of<IMemoryCache>();
            var cachEntry = Mock.Of<ICacheEntry>();
            var options = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(30),
                Priority = CacheItemPriority.Normal
            };

            mockPostService.Setup(s => s.GetTopTwenty())
                .Throws<Exception>();

            var mockMemoryCache = Mock.Get(memoryCache);
            mockMemoryCache.Setup(m => m.CreateEntry(It.IsAny<string>()))
                .Returns(cachEntry);

            var cachedResponse = memoryCache.Set<string>(key, response, options);

            var retPosts = controller.GetTopTwenty();
            var nokResult = retPosts as OkObjectResult;

            Assert.Equal((int?)HttpStatusCode.InternalServerError, ((ObjectResult)retPosts).StatusCode);
        }

        /// <summary>
        /// Create mock to return.
        /// </summary>
        /// <returns></returns>
        private List<BestPosts> GetMockBestPosts()
        {
            List<BestPosts> listPosts = new List<BestPosts>();

            // Add first post.
            listPosts.Add(new BestPosts
            {
                Title = "TurboTax’s 20-Year Fight to Stop Americans from Filing Taxes for Free",
                Uri = "https://www.propublica.org/article/inside-turbotax-20-year-fight-to-stop-americans-from-filing-their-taxes-for-free",
                PostedBy = "danso",
                Time = "17/10/2019 09:44:21",
                Score = 1503,
                CommentCount = 50
            });

            // Add second post.
            listPosts.Add(new BestPosts
            {
                Title = "Google chief: I'd disclose smart speakers before guests enter my home",
                Uri = "https://www.bbc.com/news/technology-50048144",
                PostedBy = "vezycash",
                Time = "17/10/2019 06:54:47",
                Score = 894,
                CommentCount = 68
            });

            return listPosts;
        }
    }

    public static class MockMemoryCacheService
    {
        public static IMemoryCache GetMemoryCache(object expectedValue)
        {
            var mockMemoryCache = new Mock<IMemoryCache>();
            mockMemoryCache
                .Setup(x => x.TryGetValue(It.IsAny<object>(), out expectedValue))
                .Returns(true);
            return mockMemoryCache.Object;
        }
    }
}
